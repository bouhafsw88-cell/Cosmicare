"use client";
export default function Home() {
  return (
    <main>
      <h1>Cosmicare</h1>
      <p>Site e-commerce cosmétique – paiement CIB & livraison</p>
    </main>
  );
}
